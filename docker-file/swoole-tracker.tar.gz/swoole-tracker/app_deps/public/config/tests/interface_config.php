<?php
require dirname(__DIR__)."/autoload.php";
$id = StatsCenter::getInterfaceId("test_interface_ddddd",1000402);
var_dump($id);