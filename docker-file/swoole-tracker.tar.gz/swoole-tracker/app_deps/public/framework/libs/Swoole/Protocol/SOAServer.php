<?php
namespace Swoole\Protocol;

class SOAServer extends RPCServer
{

}