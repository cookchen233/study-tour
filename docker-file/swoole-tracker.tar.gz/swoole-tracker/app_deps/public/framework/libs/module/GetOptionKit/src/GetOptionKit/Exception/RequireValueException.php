<?php
namespace GetOptionKit\Exception;

use Exception;

class RequireValueException extends Exception { }

